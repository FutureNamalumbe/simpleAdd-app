<?php



if (isset($_POST['addbt'])){
	
	$_POST['place']++;
	
	$sum = $_POST['place'];
	
	header("Location:index.php?sum=$sum"); 		
}

?>

<!DOCTYPE html>

<html lang ="en">

<head>
      <title>POST REDIRECT</title>
</head>

<body>


<div style="width:80%; height:20rem; font-size:20rem; background:#669933; color:#ff9966; text-align:center; margin:10rem auto;">

<form action="index.php" method="POST" style="float:left;">
  <input type="text" value="<?php if (isset($_GET['sum'])){echo $_GET['sum'];} else { echo '0';}?>" name="place" style="color:#FF3366; width:79.7%; height:20rem; text-align:center; font-size:20rem; font-style:Arial; position:absolute; background:#008080; "/>
  <input type="submit" value="ADD" name="addbt" style="cursor:pointer; color:#FF3366; position:absolute; z-index:999; width:7rem; height:4rem;"/>
</form>

</div>


</body>



</html>